products = [
    {"producto": "laptop", "precio": 800, "Stock": 4},
    {"producto": "mouse", "precio": 40, "Stock": 10},
    {"producto": "monitor", "precio": 400, "Stock": 3}

]
