from flask import Flask, jsonify
from products import products

app = Flask(__name__)


@app.route('/ping')
def ping():
    return jsonify({"mensaje": "pong "})


@app.route('/products')
def getProducts():
    return jsonify({"products": products})


@app.route('/products/<string:product_name>')
def getProduct(product_name):
    productsFound = [product for product in products if product['producto'] == product_name]
    return jsonify({"product": productsFound[0]})


@app.route('/products', methods=['POST'])
def addProduct():
    return 'recibido'


if __name__ == '__main__':
    app.run('127.0.0.1', debug=True, port=4000)
